"""LOSO input preparation: source labels + fixed sparse target labels only."""
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset
from scipy.spatial import cKDTree
from helper_ply import read_ply
from cave_priors import CAVE_TYPES, GeometryConfig, compute_descriptor, estimate_normals, FoldGeometricPrior


def load_manifest(path, require_17=True):
    path = Path(path).resolve()
    manifest = json.loads(path.read_text(encoding='utf-8-sig'))
    root = Path(manifest.get('data_root', '.'))
    if not root.is_absolute():
        root = path.parent/root
    scenes = manifest['scenes']
    if require_17 and len(scenes) != 17:
        raise ValueError('Paper LOSO requires exactly 17 scenes; --allow-other-scene-count is for debugging')
    ids, files = set(), set()
    for scene in scenes:
        if scene['id'] in ids:
            raise ValueError('Duplicate scene ID: ' + scene['id'])
        ids.add(scene['id'])
        scene['path'] = str((root/scene['filename']).resolve())
        if scene['path'].casefold() in files:
            raise ValueError('A scene file cannot be reused under multiple IDs')
        files.add(scene['path'].casefold())
        if scene['cave_type'] not in CAVE_TYPES:
            raise ValueError('Unknown cave_type: ' + str(scene['cave_type']))
        scene['type_index'] = CAVE_TYPES.index(scene['cave_type'])
        if not Path(scene['path']).is_file():
            raise FileNotFoundError(scene['path'])
        if 'descriptor' in scene and (len(scene['descriptor']) != 5 or not np.isfinite(scene['descriptor']).all()):
            raise ValueError('descriptor must contain five finite responses R1..R5')
    return manifest


def voxel_sparse_indices(xyz, labels, ratio=0.01, seed=0, divisions=16, minimum_fg=0.3):
    """Exact budget, without replacement, round-robin spatial voxel sampling."""
    valid = np.flatnonzero((labels == 0) | (labels == 1))
    if not (0 < ratio <= 1) or not (0 <= minimum_fg <= 1):
        raise ValueError('Invalid sparse ratio or foreground quota')
    if not len(valid):
        raise ValueError('No binary point labels found')
    budget = min(len(valid), max(1, int(round(len(valid)*ratio))))
    rng = np.random.RandomState(seed)
    span = np.maximum(np.ptp(xyz,axis=0), 1e-8)
    grid = np.clip(((xyz-xyz.min(0))/span*divisions).astype(np.int64),0,divisions-1)
    voxel = grid[:,0]+divisions*grid[:,1]+divisions**2*grid[:,2]

    def stratified(indices, count):
        if count == 0:
            return np.empty(0, np.int64)
        shuffled = rng.permutation(indices)
        ordered = shuffled[np.argsort(voxel[shuffled],kind='stable')]
        _, starts, counts = np.unique(voxel[ordered],return_index=True,return_counts=True)
        groups = np.repeat(np.arange(len(starts)),counts)
        within = np.arange(len(ordered))-starts[groups]
        group_order = rng.permutation(len(starts))
        return ordered[np.lexsort((group_order[groups],within))[:count]]

    fg = valid[labels[valid] == 1]
    fg_count = min(len(fg), int(np.ceil(budget*minimum_fg)))
    selected_fg = stratified(fg, fg_count)
    rest = np.setdiff1d(valid, selected_fg, assume_unique=True)
    selected = np.r_[selected_fg, stratified(rest, budget-fg_count)]
    return np.sort(selected)


def load_scene(scene, geometry):
    raw = read_ply(scene['path'])
    names = raw.dtype.names
    xyz = np.column_stack([raw[k] for k in ('x','y','z')]).astype(np.float32)
    if len(xyz) < 3 or not np.isfinite(xyz).all():
        raise ValueError(scene['id'] + ': invalid XYZ')
    if not all(k in names for k in ('red','green','blue')):
        raise ValueError(scene['id'] + ': RGB fields red/green/blue are required')
    rgb = np.column_stack([raw[k] for k in ('red','green','blue')]).astype(np.float32)
    if rgb.max() > 1:
        rgb /= 255.0
    if all(k in names for k in ('nx','ny','nz')):
        normals = np.column_stack([raw[k] for k in ('nx','ny','nz')]).astype(np.float32)
        if not np.isfinite(normals).all() or (np.linalg.norm(normals,axis=1) < 1e-8).any():
            normals = estimate_normals(xyz)
    else:
        normals = estimate_normals(xyz)
    normals /= np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-8)
    label_field = scene.get('label_field')
    if not label_field:
        label_field = next((k for k in ('label','class','scalar_label','Label','LABEL') if k in names),None)
    if label_field not in names:
        raise ValueError(scene['id'] + ': no semantic label field')
    labels = np.full(len(xyz),255,np.int64)
    # Explicit raw->binary mapping; no silent assumption that labels 1/2 are 0/1.
    mapping = scene.get('label_map', {'0':0,'1':1})
    for raw_value, binary in mapping.items():
        if int(binary) not in (0,1,255):
            raise ValueError('label_map outputs must be 0,1,255')
        labels[raw[label_field] == float(raw_value)] = int(binary)
    if not np.isfinite(rgb).all() or not np.isin(labels,[0,1]).any():
        raise ValueError(scene['id'] + ': invalid RGB or empty semantic annotation')
    descriptor = np.asarray(scene['descriptor'],np.float32) if 'descriptor' in scene else compute_descriptor(xyz,geometry)
    return dict(id=scene['id'],xyz=xyz,colors=np.c_[rgb,normals].astype(np.float32),
                labels=labels,type_index=scene['type_index'],descriptor=descriptor,
                enclosed=bool(scene.get('enclosed',True)),tree=cKDTree(xyz))


def prepare_fold(scenes, target_id, ratio=0.01, sampling_seed=0, prior_options=None):
    targets = [s for s in scenes if s['id'] == target_id]
    if len(targets) != 1:
        raise ValueError('Target ID must identify one scene')
    source = [s for s in scenes if s['id'] != target_id]
    target = targets[0]
    prior = FoldGeometricPrior(**(prior_options or {})).fit(
        [s['descriptor'] for s in source], [s['type_index'] for s in source],
        [s['id'] for s in source], target_id)
    train = []
    sparse = voxel_sparse_indices(target['xyz'],target['labels'],ratio,sampling_seed)
    for scene in source+[target]:
        s = dict(scene)
        s['prior'],s['deviation'] = prior.predict(s['descriptor'])
        s['is_source'] = scene['id'] != target_id
        if not s['is_source']:
            # Hidden target labels and manual cave type never enter training data.
            s['labels'] = np.full_like(scene['labels'],255)
            s['labels'][sparse] = scene['labels'][sparse]
            s['type_index'] = -1
        train.append(s)
    evaluation = dict(train[-1])
    evaluation['labels'] = target['labels'].copy()
    evaluation['labels'][sparse] = 255
    return train, evaluation, sparse, prior


def make_block(scene, indices):
    xyz = scene['xyz'][indices].copy()
    xyz -= xyz.mean(0)
    xyz /= max(float(np.linalg.norm(xyz,axis=1).max()),1e-8)
    return dict(xyz=torch.from_numpy(xyz), colors=torch.from_numpy(scene['colors'][indices].copy()),
                labels=torch.from_numpy(scene['labels'][indices].copy()),
                cave_type=torch.tensor(scene['type_index'],dtype=torch.long),
                is_source=torch.tensor(scene['is_source'],dtype=torch.bool),
                prior=torch.from_numpy(scene['prior'].copy()),deviation=torch.tensor(scene['deviation']),
                enclosed=torch.tensor(scene['enclosed']))


class TrainingBlocks(Dataset):
    """Each adjacent pair is one source block + one target block (batch size 2)."""
    def __init__(self, scenes, points=40960, steps=500):
        self.sources = [s for s in scenes if s['is_source']]
        self.target = next(s for s in scenes if not s['is_source'])
        self.points,self.steps = points,steps
        if not self.sources:
            raise ValueError('Source scenes are required')

    def __len__(self):
        return 2*self.steps

    def __getitem__(self,index):
        scene = self.sources[np.random.randint(len(self.sources))] if index%2 == 0 else self.target
        labeled = np.flatnonzero(scene['labels'] != 255)
        fg = np.flatnonzero(scene['labels'] == 1)
        candidates = fg if len(fg) and np.random.rand() < 0.5 else labeled
        center_index = np.random.choice(candidates) if len(candidates) and np.random.rand() < 0.75 else np.random.randint(len(scene['xyz']))
        candidates = scene['tree'].query(scene['xyz'][center_index],k=min(2*self.points,len(scene['xyz'])))[1]
        selected = np.random.choice(np.atleast_1d(candidates),self.points,replace=len(candidates)<self.points)
        return make_block(scene,selected)


class EvaluationBlocks(Dataset):
    """Deterministic complete coverage, one prediction per real point, padding ignored."""
    def __init__(self,scene,points=40960):
        self.scene,self.points = scene,points
        xyz = scene['xyz']
        self.order = np.lexsort((xyz[:,2],xyz[:,1],xyz[:,0]))

    def __len__(self):
        return (len(self.order)+self.points-1)//self.points

    def __getitem__(self,index):
        ids = self.order[index*self.points:(index+1)*self.points]
        real = len(ids)
        padded = np.resize(ids,self.points)
        block = make_block(self.scene,padded)
        block['point_indices'] = torch.from_numpy(padded.copy())
        block['real_mask'] = torch.arange(self.points)<real
        return block


def augment(batch,strong=False):
    """Retain point indices; replacement/cutout points have no pseudo/supervised loss.

    Normals rotate/reflect with coordinates, RGB perturbations affect RGB only.
    Cutout never compacts arrays, preserving weak/strong teacher correspondence.
    """
    result = {k:v.clone() for k,v in batch.items()}
    b,n,_ = result['xyz'].shape
    device = result['xyz'].device
    result['view_valid'] = torch.ones(b,n,dtype=torch.bool,device=device)
    for i in range(b):
        degrees = (180 if bool(batch['enclosed'][i]) else 45) if strong else 15
        angle = (torch.rand((),device=device)*2-1)*degrees*np.pi/180
        c,s = angle.cos(),angle.sin()
        rotation = torch.eye(3,device=device)
        rotation[0,0],rotation[0,1],rotation[1,0],rotation[1,1] = c,-s,s,c
        if torch.rand((),device=device)<0.5:
            rotation[:,0] *= -1
        result['xyz'][i] = result['xyz'][i] @ rotation
        result['colors'][i,:,3:] = result['colors'][i,:,3:] @ rotation
        lo,hi = (0.8,1.2) if strong else (0.95,1.05)
        result['xyz'][i] *= lo+(hi-lo)*torch.rand((),device=device)
        result['xyz'][i] += (0.01 if strong else 0.001)*torch.randn_like(result['xyz'][i])
        if strong:
            rgb = result['colors'][i,:,:3]
            if torch.rand((),device=device)<0.8:
                rgb.mul_(0.8+0.4*torch.rand((),device=device)).add_((torch.rand((),device=device)-0.5)*0.2)
            rgb.add_(0.02*torch.randn_like(rgb)).clamp_(0,1)
            if torch.rand((),device=device)<0.2:
                rgb.zero_()
            fraction = float(0.2+0.1*torch.rand(()))
            removed = torch.randperm(n,device=device)[:int(n*fraction)]
            valid = result['view_valid'][i]
            valid[removed] = False
            xyz = result['xyz'][i]
            for _ in range(int(torch.randint(1,3,()).item())):
                center = xyz[torch.randint(n,(),device=device)]
                half = (xyz.amax(0)-xyz.amin(0))*0.1
                proposed = ((xyz-center).abs() < half).all(-1) & valid
                candidates = proposed.nonzero().flatten()
                capacity = max(0,int(n*0.4)-int((~valid).sum()))
                valid[candidates[:capacity]] = False
            # Replace removed inputs by retained points while masking their losses.
            kept = valid.nonzero().flatten()
            removed = (~valid).nonzero().flatten()
            repl = kept[torch.randint(len(kept),(len(removed),),device=device)]
            xyz[removed] = xyz[repl]
            result['colors'][i,removed] = result['colors'][i,repl]
    return result
