"""PTv3_MT_S3DIS.py - SA-SegNet with a lightweight PTv3-style backbone.
This custom implementation is not the complete official PTv3 architecture.
With cfg.use_cave_router enabled, five anchored and three adaptive prototype
slots provide context to every decoder stage.

The backbone uses Morton-order serialized window attention, multiple shifted
serialization orders, hierarchical subsampling, and a U-Net decoder with skips.
Outputs include foreground/background segmentation, L1/L2 classification,
auxiliary segmentation heads, and features for consistency/prototype learning.

    model = SA_SegNet(cfg)
    seg, l1, l2, feat, aux = model(batch)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ===================================================================
# Utility functions
# ===================================================================

def make_gn(c, min_group=1):
    """GroupNorm with a group count that divides the channel count."""
    for g in [32, 16, 8, 4, 2, 1]:
        if c >= g and c % g == 0:
            return nn.GroupNorm(g, c)
    return nn.GroupNorm(min_group, c)


# --- Z-Order (Morton Code) serialization --------------------------------

def _spread_bits_torch(v):
    """
    Spread the lowest 21 bits of an int64 tensor across 63 bits for Morton encoding.
    v: LongTensor
    """
    v = v & 0x1FFFFF
    v = (v | (v << 32)) & 0x1F00000000FFFF
    v = (v | (v << 16)) & 0x1F0000FF0000FF
    v = (v | (v << 8))  & 0x100F00F00F00F00F
    v = (v | (v << 4))  & 0x10C30C30C30C30C3
    v = (v | (v << 2))  & 0x1249249249249249
    return v


def z_order_encode(xyz, depth=10):
    """
    Encode floating-point coordinates (B, N, 3) as Morton codes (B, N).
    depth: quantization bits per axis (<=21)
    """
    B, N, _ = xyz.shape
    mn = xyz.min(dim=1, keepdim=True)[0]
    rng = (xyz.max(dim=1, keepdim=True)[0] - mn).clamp(min=1e-8)
    norm = (xyz - mn) / rng

    scale = (1 << depth) - 1
    qxyz = (norm * scale).long().clamp(0, scale)

    codes = (_spread_bits_torch(qxyz[..., 0]) |
             (_spread_bits_torch(qxyz[..., 1]) << 1) |
             (_spread_bits_torch(qxyz[..., 2]) << 2))
    return codes


def serialize_points(xyz, shift=None, depth=10):
    """
    Sort points by z-order.
    Returns: order (B,N), inverse (B,N)
    """
    if shift is not None:
        xyz = xyz + shift.to(xyz.device).unsqueeze(0).unsqueeze(0)
    codes = z_order_encode(xyz, depth=depth)
    order = codes.argsort(dim=1)
    inverse = order.argsort(dim=1)
    return order, inverse


def gather_by_order(x, order):
    """Reorder features using order.x: (B, N, C)  order: (B, N)"""
    return torch.gather(x, 1, order.unsqueeze(-1).expand(-1, -1, x.shape[-1]))


def knn_interpolate(x_sub, xyz_sub, xyz_full, k=3):
    """
    Upsample using distance-weighted kNN interpolation.
    x_sub:    (B, N_sub, C)
    xyz_sub:  (B, N_sub, 3)
    xyz_full: (B, N_full, 3)
    Returns:  (B, N_full, C)
    """
    B, N_full, _ = xyz_full.shape
    N_sub = xyz_sub.shape[1]
    C = x_sub.shape[-1]
    k = min(k, N_sub)

    # Compute cdist in chunks to limit memory use.
    chunk = 2048
    out_parts = []
    for start in range(0, N_full, chunk):
        end = min(start + chunk, N_full)
        q = xyz_full[:, start:end]                             # (B, L, 3)
        dist = torch.cdist(q.float(), xyz_sub.float())         # cdist has no CUDA half kernel
        knn_d, knn_i = dist.topk(k, dim=-1, largest=False)    # (B, L, k)
        w = 1.0 / knn_d.clamp(min=1e-8)
        w = w / w.sum(dim=-1, keepdim=True)                    # (B, L, k)

        knn_i_flat = knn_i.reshape(B, -1)                      # (B, L*k)
        knn_feat = torch.gather(
            x_sub, 1,
            knn_i_flat.unsqueeze(-1).expand(-1, -1, C)
        ).reshape(B, end - start, k, C)                        # (B, L, k, C)

        interp = (knn_feat * w.unsqueeze(-1)).sum(dim=2)       # (B, L, C)
        out_parts.append(interp)

    return torch.cat(out_parts, dim=1)


# ===================================================================
# Core modules
# ===================================================================

class PointPatchEmbed(nn.Module):
    """Point embedding: 9D input (xyz + rgb + normal) -> d_model channels."""

    def __init__(self, in_channels=9, d_model=48):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(in_channels, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Linear(d_model, d_model),
        )

    def forward(self, xyz, colors):
        return self.proj(torch.cat([xyz, colors], dim=-1))


class SerializedAttention(nn.Module):
    """Serialized window attention inspired by PTv3.
    Points are sorted by Morton order before fixed-window multihead attention.
    Outputs from multiple shifted serialization orders are averaged.
    """

    def __init__(self, d_model, num_heads=4, window_size=256,
                 num_serializations=2, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        self.window_size = window_size
        self.num_ser = num_serializations
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(d_model, 3 * d_model)
        self.proj = nn.Linear(d_model, d_model)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_drop = nn.Dropout(proj_drop)

        # Learnable relative position bias within each window.
        self.rel_pos_bias = nn.Parameter(
            torch.zeros(num_heads, window_size, window_size))
        nn.init.trunc_normal_(self.rel_pos_bias, std=0.02)

        # Shifts for multiple serialization orders
        shifts = [torch.zeros(3)]
        for _ in range(num_serializations - 1):
            shifts.append(torch.randn(3) * 0.1)
        self.register_buffer('shifts', torch.stack(shifts))

    def _window_attention(self, x, B, N):
        """Apply window attention to the sorted sequence.x: (B, N, C)"""
        W = self.window_size
        pad = (W - N % W) % W
        if pad > 0:
            x = F.pad(x, (0, 0, 0, pad))
        Np = x.shape[1]
        nW = Np // W

        x = x.view(B, nW, W, self.d_model)
        qkv = self.qkv(x).reshape(B, nW, W, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(3, 0, 1, 4, 2, 5)    # (3, B, nW, H, W, hd)
        q, k, v = qkv.unbind(0)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        rpb = self.rel_pos_bias[:, :W, :W]
        attn = attn + rpb.unsqueeze(0).unsqueeze(0)

        if pad > 0:
            mask = torch.zeros(1, nW, 1, 1, W, device=x.device)
            mask[:, -1, :, :, W - pad:] = float('-inf')
            attn = attn + mask

        attn = self.attn_drop(attn.softmax(dim=-1))
        out = (attn @ v).transpose(2, 3).reshape(B, nW, W, self.d_model)
        out = out.reshape(B, Np, self.d_model)

        if pad > 0:
            out = out[:, :N]
        return out

    def forward(self, x, xyz):
        """x: (B, N, C)  xyz: (B, N, 3) -> (B, N, C)"""
        B, N, C = x.shape
        out_acc = torch.zeros_like(x)

        for si in range(self.num_ser):
            shift = self.shifts[si] if si > 0 else None
            order, inverse = serialize_points(xyz, shift=shift)
            x_sorted = gather_by_order(x, order)
            x_attn = self._window_attention(x_sorted, B, N)
            x_attn = gather_by_order(x_attn, inverse)
            out_acc = out_acc + x_attn

        out = out_acc / self.num_ser
        return self.proj_drop(self.proj(out))


class DropPath(nn.Module):
    """Stochastic depth."""
    def __init__(self, p=0.0):
        super().__init__()
        self.p = p

    def forward(self, x):
        if not self.training or self.p == 0.:
            return x
        keep = 1 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        mask = torch.bernoulli(torch.full(shape, keep, device=x.device))
        return x * mask / keep


class PTv3Block(nn.Module):
    """
    Point Transformer V3-style block:
      LayerNorm -> SerializedAttention -> residual
      LayerNorm -> FFN -> residual
    """

    def __init__(self, d_model, num_heads=4, window_size=256,
                 num_serializations=2, mlp_ratio=4.0, drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = SerializedAttention(
            d_model, num_heads=num_heads, window_size=window_size,
            num_serializations=num_serializations,
            attn_drop=drop, proj_drop=drop)
        self.norm2 = nn.LayerNorm(d_model)
        mlp_hidden = int(d_model * mlp_ratio)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, mlp_hidden),
            nn.GELU(),
            nn.Dropout(drop),
            nn.Linear(mlp_hidden, d_model),
            nn.Dropout(drop),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x, xyz):
        x = x + self.drop_path(self.attn(self.norm1(x), xyz))
        x = x + self.drop_path(self.ffn(self.norm2(x)))
        return x


# --- Hierarchical pooling --------------------------------------------------

class GridPooling(nn.Module):
    """Uniformly spaced z-order subsampling and feature projection."""

    def __init__(self, in_channels, out_channels, ratio=4):
        super().__init__()
        self.ratio = ratio
        self.proj = nn.Sequential(
            nn.Linear(in_channels, out_channels),
            nn.LayerNorm(out_channels),
            nn.GELU(),
        )

    def forward(self, x, xyz):
        """
        x: (B,N,C)  xyz: (B,N,3)
        Returns: x_down (B,M,C'), xyz_down (B,M,3), pool_idx (B,M)
        """
        B, N, C = x.shape
        M = max(1, N // self.ratio)

        order, _ = serialize_points(xyz)
        step = max(1, N // M)
        sample_pos = torch.arange(0, min(N, M * step), step, device=xyz.device)[:M]
        if sample_pos.shape[0] < M:
            extra = torch.randint(0, N, (M - sample_pos.shape[0],), device=xyz.device)
            sample_pos = torch.cat([sample_pos, extra])

        pool_idx = torch.gather(order, 1, sample_pos.unsqueeze(0).expand(B, -1))
        xyz_down = torch.gather(xyz, 1, pool_idx.unsqueeze(-1).expand(-1, -1, 3))
        x_down = torch.gather(x, 1, pool_idx.unsqueeze(-1).expand(-1, -1, C))
        x_down = self.proj(x_down)

        return x_down, xyz_down, pool_idx


# --- Upsampling module --------------------------------------------------

class PointUpsampleBlock(nn.Module):
    """kNN interpolation, skip connection fusion, and projection."""

    def __init__(self, in_channels, out_channels, skip_channels=0):
        super().__init__()
        total = in_channels + skip_channels
        self.proj = nn.Sequential(
            nn.Linear(total, out_channels),
            nn.LayerNorm(out_channels),
            nn.GELU(),
        )

    def forward(self, x_sub, xyz_sub, xyz_full, skip=None):
        """
        x_sub:    (B, N_sub, C_in)
        xyz_sub:  (B, N_sub, 3)
        xyz_full: (B, N_full, 3)
        skip:     (B, N_full, C_skip) optional
        """
        x_up = knn_interpolate(x_sub, xyz_sub, xyz_full, k=3)
        if skip is not None:
            x_up = torch.cat([x_up, skip], dim=-1)
        return self.proj(x_up)


# --- Scene-level attentive pooling --------------------------------------------

class SceneAttentivePooling(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.score = nn.Sequential(
            nn.Linear(c, c // 2), nn.ReLU(), nn.Linear(c // 2, 1))

    def forward(self, x):
        w = torch.softmax(self.score(x), dim=1)
        return (w * x).sum(dim=1)


# --- Auxiliary heads for deep supervision ----------------------------------------------

class SegHead(nn.Module):
    def __init__(self, in_c, nc):
        super().__init__()
        mid = max(32, in_c // 2)
        self.h = nn.Sequential(
            nn.Linear(in_c, mid),
            nn.LayerNorm(mid), nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(mid, nc),
        )

    def forward(self, x):
        return self.h(x)


# ===================================================================
# Main network: SA_SegNet (Point Transformer V3-style backbone)
# ===================================================================

class SA_SegNet(nn.Module):
    """
    Multitask segmentation network inspired by Point Transformer V3.

    Retains the original RandLA-Net return interface:
        seg, l1, l2, feat, aux = model(batch)

    Required cfg fields: num_classes, num_layers, d_out, sub_sampling_ratio; k_n is retained for compatibility.
    """

    PRIOR_DIM = 64

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        num_layers = cfg.num_layers
        d_out = cfg.d_out
        self.d_out = d_out

        d_embed = d_out[0]
        base_win = 256

        # --- Patch Embedding -------------------------------------
        self.patch_embed = PointPatchEmbed(in_channels=9, d_model=d_embed)

        # --- Encoder ---------------------------------------------
        self.enc_projs = nn.ModuleList()
        self.enc_blocks = nn.ModuleList()
        self.enc_pools = nn.ModuleList()

        for i in range(num_layers):
            d_in = d_out[i - 1] if i > 0 else d_embed
            d_o = d_out[i]
            n_heads = max(2, d_o // 32)
            win = max(32, base_win // (2 ** i))

            if d_in != d_o:
                self.enc_projs.append(
                    nn.Sequential(nn.Linear(d_in, d_o), nn.LayerNorm(d_o)))
            else:
                self.enc_projs.append(nn.Identity())

            blocks = nn.ModuleList([
                PTv3Block(d_o, num_heads=n_heads, window_size=win,
                          num_serializations=2, mlp_ratio=4.0,
                          drop=0.0, drop_path=0.05 * i)
                for _ in range(2)
            ])
            self.enc_blocks.append(blocks)

            if i < num_layers - 1:
                ratio = cfg.sub_sampling_ratio[i]
                self.enc_pools.append(GridPooling(d_o, d_o, ratio=ratio))

        # --- Bottleneck ------------------------------------------
        d_bot = d_out[-1]
        self.bottleneck = nn.Sequential(
            nn.Linear(d_bot, d_bot), nn.LayerNorm(d_bot), nn.GELU())
        self.scene_pool = SceneAttentivePooling(d_bot)

        # --- Multitask heads: L1 (3 classes) + L2 (5 cave types) --------------------
        self.fc_l1 = nn.Sequential(
            nn.Linear(d_bot, 64), nn.ReLU(), nn.Linear(64, 3))
        self.fc_l2_pre = nn.Sequential(
            nn.Linear(d_bot, self.PRIOR_DIM), nn.ReLU())
        self.fc_l2_out = nn.Linear(self.PRIOR_DIM, 5)
        self.use_cave_router = getattr(cfg, 'use_cave_router', False)
        if self.use_cave_router:
            from paper_modules import CavePrototypeRouter
            self.router = CavePrototypeRouter(
                d_bot, embed_dim=getattr(cfg, 'typo_embed_dim', 128),
                temperature=getattr(cfg, 'route_temperature', 0.5),
                gumbel_temperature=getattr(cfg, 'gumbel_temperature', 0.5),
                prior_weight=getattr(cfg, 'prior_weight', 1.0),
                deviation_weight=getattr(cfg, 'deviation_weight', 1.0))
            self.router_fg_head = nn.Linear(d_bot, cfg.num_classes)
            self.context_projection = nn.Linear(getattr(cfg, 'typo_embed_dim', 128), self.PRIOR_DIM)

        # --- Decoder ---------------------------------------------
        self.dec_ups = nn.ModuleList()
        self.dec_blocks = nn.ModuleList()
        self.aux_heads = nn.ModuleList()

        d_dec = d_bot
        for i in range(num_layers - 1):
            skip_dim = d_out[-(i + 2)]
            d_up_out = skip_dim * 2
            n_heads = max(2, d_up_out // 32)
            win = max(32, base_win // (2 ** max(0, num_layers - 2 - i)))

            self.dec_ups.append(
                PointUpsampleBlock(
                    d_dec, d_up_out,
                    skip_channels=skip_dim + self.PRIOR_DIM))
            self.dec_blocks.append(
                PTv3Block(d_up_out, num_heads=n_heads, window_size=win,
                          num_serializations=2, mlp_ratio=2.0))
            self.aux_heads.append(SegHead(d_up_out, cfg.num_classes))
            d_dec = d_up_out

        # --- Final segmentation head ------------------------------------------
        self.out_feat_dim = d_dec

        self.final_seg = nn.Sequential(
            nn.Linear(d_dec, 64), nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(32, cfg.num_classes),
        )

    def forward(self, batch, channel_mask=None, return_routing=False):
        xyz = batch['xyz']
        colors = batch['colors']
        B, N, _ = xyz.shape

        # -- Patch Embedding --
        x = self.patch_embed(xyz, colors)

        # -- Encoder --
        enc_coords = [xyz]
        enc_feats = []

        for i in range(len(self.enc_blocks)):
            x = self.enc_projs[i](x)
            cur_xyz = enc_coords[-1]
            for blk in self.enc_blocks[i]:
                x = blk(x, cur_xyz)
            enc_feats.append(x)

            if i < len(self.enc_pools):
                x, xyz_down, _ = self.enc_pools[i](x, cur_xyz)
                enc_coords.append(xyz_down)

        # -- Bottleneck --
        x = self.bottleneck(x)
        if channel_mask is not None:
            x = x * channel_mask.reshape(1, 1, -1)

        # -- Global scene descriptor -> multitask heads --
        vg = self.scene_pool(x)
        l1 = self.fc_l1(vg)
        sp = self.fc_l2_pre(vg)
        l2 = self.fc_l2_out(sp)
        routing = None
        if self.use_cave_router:
            routing = self.router(x, enc_coords[-1], self.router_fg_head(x),
                                  batch['prior'], batch['deviation'])
            sp = self.context_projection(routing['context']).to(x.dtype)
            l2 = routing['anchor_deterministic'].clamp_min(1e-8).log()

        # -- Decoder --
        aux = []
        aux_xyz = []
        for i in range(len(self.dec_ups)):
            skip_feat = enc_feats[-(i + 2)]
            target_xyz = enc_coords[-(i + 2)]
            source_xyz = enc_coords[-(i + 1)]

            sp_exp = sp.unsqueeze(1).expand(-1, skip_feat.shape[1], -1)
            skip_with_prior = torch.cat([skip_feat, sp_exp], dim=-1)

            x = self.dec_ups[i](x, source_xyz, target_xyz, skip=skip_with_prior)
            x = self.dec_blocks[i](x, target_xyz)
            aux.append(self.aux_heads[i](x))
            aux_xyz.append(target_xyz)

        seg = self.final_seg(x)
        feat = x

        if return_routing:
            return dict(seg=seg, feat=feat, aux=aux, aux_xyz=aux_xyz, routing=routing)
        return seg, l1, l2, feat, aux


# ===================================================================
# Quick self-test
# ===================================================================
if __name__ == '__main__':
    from dataclasses import dataclass

    @dataclass
    class TestCfg:
        num_classes = 2
        num_layers = 5
        d_out = [16, 64, 128, 256, 512]
        sub_sampling_ratio = [4, 4, 4, 4, 4]
        k_n = 16
        num_points = 40960

    cfg_test = TestCfg()
    model = SA_SegNet(cfg_test)

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {n_params:,}")
    print(f"out_feat_dim: {model.out_feat_dim}")

    B, N = 2, 4096
    batch = {'xyz': torch.randn(B, N, 3), 'colors': torch.randn(B, N, 6)}
    seg, l1, l2, feat, aux = model(batch)
    print(f"seg:  {seg.shape}")
    print(f"l1:   {l1.shape}")
    print(f"l2:   {l2.shape}")
    print(f"feat: {feat.shape}")
    print(f"aux:  {[a.shape for a in aux]}")
    print("PTv3 forward test passed")
