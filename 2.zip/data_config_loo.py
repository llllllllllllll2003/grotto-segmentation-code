"""Scene-level LOSO metadata, replacing the old 4-colossal + 1-hall split."""
from paper_data import load_manifest


def get_all_folds(manifest_path='scenes.example.json',require_17=True):
    scenes = load_manifest(manifest_path,require_17)['scenes']
    return [dict(fold_name=target['id'],source_ids=[s['id'] for s in scenes if s['id']!=target['id']],
                 target_id=target['id']) for target in scenes]


def print_fold_summary(manifest_path='scenes.example.json'):
    for fold in get_all_folds(manifest_path):
        print(fold['fold_name'], 'source=',fold['source_ids'],'target=',fold['target_id'])
