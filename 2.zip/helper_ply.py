import numpy as np
from plyfile import PlyData, PlyElement


def read_ply(filename):

    return PlyData.read(filename).elements[0].data


def write_ply(filename, field_list, field_names):

    if filename.endswith('.ply'):
        filename = filename[:-4]
    elements = [PlyElement.describe(d, n)
                for d, n in zip(field_list, field_names)]
    PlyData(elements).write(filename + '.ply')
