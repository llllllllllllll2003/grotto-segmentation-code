"""Paper training path. No hidden target labels are used for model selection."""
import copy
import csv
import json
import random
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from PTv3_MT_S3DIS import SA_SegNet, knn_interpolate
from paper_data import TrainingBlocks, EvaluationBlocks, augment
from paper_modules import (CavePrototypeRouter, ClassAdaptiveThreshold,
                           DomainPrototypeBank, complementary_channel_masks, pseudo_losses)


@dataclass
class PaperConfig:
    name: str = 'A5'
    epochs: int = 100
    learning_rate: float = 0.002
    min_learning_rate: float = 0.00001
    batch_size: int = 2
    num_points: int = 40960
    steps_per_epoch: int = 500
    workers: int = 0
    num_classes: int = 2
    num_layers: int = 5
    d_out: tuple = (16,64,128,256,512)
    sub_sampling_ratio: tuple = (4,4,4,4,2)
    use_cave_router: bool = True
    typo_embed_dim: int = 128
    route_temperature: float = 0.5
    gumbel_temperature: float = 0.5
    prior_weight: float = 1.0
    deviation_weight: float = 1.0
    prior_smoothing: float = 0.1
    adaptive_limit: float = 0.1
    sparse_weight: float = 1.0
    geo_weight: float = 1.0
    use_teachers: bool = True
    use_filtering: bool = True
    use_alignment: bool = True
    teacher_momenta: tuple = (0.99,0.999)
    channel_keep_rate: float = 0.625
    channel_shared_rate: float = 0.25
    sat_momentum: float = 0.999
    sat_floors: tuple = (0.85,0.65)
    sat_ceiling: float = 0.95
    focal_gamma: float = 1.5
    w_aux: float = 0.4
    w_unsup: float = 1.0
    unsup_ramp_epochs: int = 20
    w_typology: float = 0.2
    w_consistency: float = 0.05
    w_alignment: float = 0.1
    w_proto: float = 0.05
    proto_min_points: int = 10
    proto_confidence: float = 0.65
    proto_momentum_start: float = 0.9
    proto_momentum_end: float = 0.999
    proto_warmup_epochs: int = 10
    proto_decay: float = 0.001
    min_trusted_prototypes: int = 4
    proto_temperature: float = 0.07
    transport_rank: int = 3
    amp: bool = True


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


@torch.no_grad()
def update_ema(student,teacher,momentum):
    parameters = dict(student.named_parameters())
    for name,param in teacher.named_parameters():
        param.lerp_(parameters[name],1-momentum)
    # Serialization shifts and other buffers must be identical at evaluation.
    buffers = dict(student.named_buffers())
    for name,buffer in teacher.named_buffers():
        buffer.copy_(buffers[name])


def class_weights(scenes):
    counts = np.zeros(2,dtype=np.float64)
    for scene in scenes:
        for c in range(2):
            counts[c] += (scene['labels'] == c).sum()
    if (counts == 0).any():
        raise ValueError('Both semantic classes need labeled training points')
    inverse = 1/counts
    return torch.tensor(inverse/inverse.mean(),dtype=torch.float32)


def supervised_loss(logits,labels,weights):
    valid = labels != 255
    if not valid.any():
        return logits.sum()*0
    logp = logits[valid].float().log_softmax(-1)
    gt = labels[valid]
    # Eq. (18): average class-weighted CE by labeled point count.
    ce = (-logp.gather(-1,gt[:,None]).squeeze(-1)*weights[gt]).mean()
    fg = logp.exp()[:,1]
    target = (gt == 1).float()
    dice = 1-(2*(fg*target).sum()+1e-6)/(fg.sum()+target.sum()+1e-6)
    return ce+dice


def auxiliary_loss(output, batch, labels, weights):
    terms = []
    for logits,coords in zip(output['aux'],output['aux_xyz']):
        if logits.shape[1] != labels.shape[1]:
            logits = knn_interpolate(logits,coords,batch['xyz'])
        valid = labels != 255
        if valid.any():
            logp = logits[valid].float().log_softmax(-1)
            terms.append((-logp.gather(-1,labels[valid].unsqueeze(-1)).squeeze(-1)*weights[labels[valid]]).mean())
    return sum(terms)/len(terms) if terms else output['seg'].sum()*0


def compute_training_loss(student,teachers,bank,sat,batch,config,weights,epoch):
    weak,strong = augment(batch),augment(batch,strong=True)
    output = student(strong,return_routing=True)
    labels = batch['labels'].clone()
    labels[~strong['view_valid']] = 255
    zero = output['seg'].sum()*0
    losses = dict(sup=supervised_loss(output['seg'],labels,weights),
                  aux=auxiliary_loss(output,strong,labels,weights),typ=zero,unsup=zero,
                  con=zero,align=zero,proto=zero)
    if config.use_cave_router:
        losses['typ'] = CavePrototypeRouter.constraint_loss(
            output['routing'],batch['cave_type'],batch['is_source'],batch['prior'],
            config.prior_smoothing,config.adaptive_limit,config.sparse_weight,config.geo_weight)
    pseudo = torch.zeros_like(labels)
    consensus = torch.zeros_like(labels,dtype=torch.bool)
    confidence = torch.ones_like(labels,dtype=torch.float32)
    if teachers:
        masks = (None,None)
        if config.use_filtering:
            masks = complementary_channel_masks(config.d_out[-1],config.channel_keep_rate,
                                                config.channel_shared_rate,labels.device)
        with torch.no_grad():
            teacher_outputs = [t(weak,channel_mask=m,return_routing=True) for t,m in zip(teachers,masks)]
            pseudo,consensus,soft,confidence = sat.consensus(*teacher_outputs,batch['labels'],batch['is_source'],config.use_filtering)
            consensus &= strong['view_valid']
        losses['unsup'],losses['con'] = pseudo_losses(output['seg'],pseudo,consensus,soft,config.focal_gamma)
    if bank is not None:
        # Source prototypes always use source GT; target prototypes only accepted
        # unlabeled-target consensus. The hidden target GT is never an argument.
        src = batch['is_source'][:,None]
        valid = (src & (labels != 255)) | consensus
        proto_labels = torch.where(src,labels,pseudo)
        proto_confidence = torch.where(src,torch.ones_like(confidence),confidence)
        losses['align'],losses['proto'] = bank(output['feat'],output['routing']['assignments'],
            proto_labels,valid,batch['is_source'],proto_confidence,epoch)
    ramp = min(1.,epoch/max(1,config.unsup_ramp_epochs))
    total = (losses['sup']+config.w_aux*losses['aux']+config.w_typology*losses['typ']
             +config.w_unsup*ramp*losses['unsup']+config.w_consistency*losses['con']
             +config.w_alignment*losses['align']+config.w_proto*losses['proto'])
    return total,losses,int(consensus.sum())


def metrics_from_confusion(confusion):
    cm = np.asarray(confusion,dtype=np.float64)
    diagonal = cm.diagonal()
    union = cm.sum(1)+cm.sum(0)-diagonal
    iou = np.divide(diagonal,union,out=np.zeros(2),where=union>0)
    recall = np.divide(diagonal,cm.sum(1),out=np.zeros(2),where=cm.sum(1)>0)
    return dict(oa=float(diagonal.sum()/max(1,cm.sum())),macc=float(recall.mean()),
                miou=float(iou.mean()),iou_fg=float(iou[1]),points=int(cm.sum()))


@torch.no_grad()
def evaluate(model,scene,config,device):
    model.eval()
    confusion = np.zeros((2,2),np.int64)
    coverage = np.zeros(len(scene['xyz']),dtype=np.int32)
    predictions = np.zeros(len(scene['xyz']),np.int64)
    loader = DataLoader(EvaluationBlocks(scene,config.num_points),batch_size=1,shuffle=False)
    for batch in loader:
        indices = batch.pop('point_indices')[0].numpy()
        real = batch.pop('real_mask')[0].numpy()
        batch = {k:v.to(device) for k,v in batch.items()}
        output = model(batch,return_routing=True)
        pred = output['seg'][0].argmax(-1).cpu().numpy()
        predictions[indices[real]] = pred[real]
        coverage[indices[real]] += 1
    if not np.all(coverage == 1):
        raise RuntimeError('Evaluation must visit each original point exactly once')
    gt = scene['labels']
    valid = gt != 255
    confusion += np.bincount(gt[valid]*2+predictions[valid],minlength=4).reshape(2,2)
    return metrics_from_confusion(confusion),predictions,confusion


def train_fold(config,train_scenes,evaluation,seed,output_dir,prior=None,sparse_indices=None):
    if config.batch_size != 2:
        raise ValueError('Paired source/target sampler requires batch_size=2')
    if config.epochs < 1 or config.steps_per_epoch < 1:
        raise ValueError('epochs and steps_per_epoch must be positive')
    set_seed(seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    directory = Path(output_dir)/evaluation['id']/config.name/('seed_'+str(seed))
    directory.mkdir(parents=True,exist_ok=True)
    student = SA_SegNet(config).to(device)
    teachers = [copy.deepcopy(student).eval().requires_grad_(False) for _ in range(2)] if config.use_teachers else []
    bank = DomainPrototypeBank(student.out_feat_dim,min_points=config.proto_min_points,
        confidence_threshold=config.proto_confidence,momentum_start=config.proto_momentum_start,
        momentum_end=config.proto_momentum_end,warmup_epochs=config.proto_warmup_epochs,
        decay=config.proto_decay,min_trusted=config.min_trusted_prototypes,
        temperature=config.proto_temperature,rank=config.transport_rank).to(device) if config.use_alignment else None
    sat = ClassAdaptiveThreshold(config.sat_momentum,config.sat_floors,config.sat_ceiling).to(device)
    weights = class_weights(train_scenes).to(device)
    loader = DataLoader(TrainingBlocks(train_scenes,config.num_points,config.steps_per_epoch),
                        batch_size=2,shuffle=False,num_workers=config.workers,pin_memory=device.type=='cuda')
    optimizer = torch.optim.Adam(student.parameters(),lr=config.learning_rate)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,config.epochs,eta_min=config.min_learning_rate)
    amp = config.amp and device.type == 'cuda'
    scaler = torch.amp.GradScaler('cuda',enabled=amp)
    history = []
    for epoch in range(config.epochs):
        student.train()
        totals,steps,accepted = {},0,0
        for batch in loader:
            batch = {k:v.to(device) for k,v in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,enabled=amp):
                loss,parts,count = compute_training_loss(student,teachers,bank,sat,batch,config,weights,epoch)
            if not torch.isfinite(loss):
                raise FloatingPointError('Non-finite training loss; aborting instead of dropping batches')
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(student.parameters(),5.)
            scale_before = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            if scaler.get_scale() >= scale_before:
                for teacher,momentum in zip(teachers,config.teacher_momenta):
                    update_ema(student,teacher,momentum)
            steps += 1
            accepted += count
            for key,value in parts.items():
                totals[key] = totals.get(key,0.)+float(value.detach())
        row = dict(epoch=epoch+1,lr=optimizer.param_groups[0]['lr'],accepted_pseudo=accepted,
                   **{key:value/steps for key,value in totals.items()})
        history.append(row)
        scheduler.step()
        print(f"{evaluation['id']} {config.name} seed={seed} epoch={epoch+1}/{config.epochs} "
              f"sup={row['sup']:.4f} unsup={row['unsup']:.4f} align={row['align']:.4f} accepted={accepted}",flush=True)
    # Evaluate ONLY after the final fixed epoch: no hidden-99% best checkpoint
    # selection, early stopping, fold-dependent tuning or automatic seed restart.
    result,predictions,confusion = evaluate(student,evaluation,config,device)
    prior_state = None if prior is None else dict(mean=prior.mean,std=prior.std,source_ids=prior.source_ids,
        temperature=prior.temperature,deviation_temperature=prior.deviation_temperature,std_floor=prior.std_floor)
    checkpoint = dict(student=student.state_dict(),teachers=[t.state_dict() for t in teachers],
        bank=bank.state_dict() if bank is not None else None,sat=sat.state_dict(),config=asdict(config),
        seed=seed,prior=prior_state,sparse_indices=sparse_indices,metrics=result,
        optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),scaler=scaler.state_dict())
    torch.save(checkpoint,directory/'final.pth')
    np.savez_compressed(directory/'evaluation.npz',prediction=predictions,confusion=confusion,
                        sparse_indices=sparse_indices)
    (directory/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    with (directory/'history.csv').open('w',newline='',encoding='utf-8') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    return result
