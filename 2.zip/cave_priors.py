"""Paper Sec. 3.3.1, Eqs. (1)-(5). Geometry uses XYZ only, never semantic labels.

The paper does not specify plane extraction / cavity detection parameters. The
defaults below are explicit operational choices; a manifest may supply measured
five-dimensional descriptors to replace automatic estimates.
"""
from dataclasses import dataclass
import numpy as np
from scipy.spatial import cKDTree

CAVE_TYPES = ('colossal', 'nirvana', 'central_pillar', 'hall', 'meditation')


@dataclass
class GeometryConfig:
    max_points: int = 8192
    small_k: int = 16
    large_k: int = 64
    plane_threshold: float = 0.015
    max_planes: int = 6
    ransac_trials: int = 100
    edge_angle_degrees: float = 35.0
    cavity_threshold: float = 0.01
    cavity_edge_weight: float = 0.5


def local_frame(xyz):
    centered = np.asarray(xyz, dtype=np.float64) - np.mean(xyz, axis=0)
    _, basis = np.linalg.eigh(centered.T @ centered / max(1, len(centered)))
    # Identify the PCA direction closest to acquisition gravity (input Z).
    # The paper leaves the mapping of sorted PCs to Hx,Hy,Hz unspecified.
    vertical = int(np.argmax(np.abs(basis[2])))
    horizontal = [i for i in (2, 1, 0) if i != vertical]
    basis = basis[:, horizontal + [vertical]]
    for j in range(3):
        if basis[np.argmax(np.abs(basis[:, j])), j] < 0:
            basis[:, j] *= -1
    return centered @ basis


def estimate_normals(xyz, k=16):
    xyz = np.asarray(xyz, dtype=np.float64)
    if len(xyz) < 3:
        raise ValueError('At least three points are required to estimate normals')
    idx = cKDTree(xyz).query(xyz, k=min(k, len(xyz)))[1]
    normals = []
    for start in range(0, len(xyz), 2048):
        neighbors = xyz[idx[start:start + 2048]]
        centered = neighbors - neighbors.mean(1, keepdims=True)
        _, vec = np.linalg.eigh(np.einsum('nki,nkj->nij', centered, centered))
        normals.append(vec[:, :, 0])
    normals = np.concatenate(normals)
    signs = np.sign((normals * (xyz - xyz.mean(0))).sum(-1))
    normals *= np.where(signs == 0, 1, signs)[:, None]
    return normals.astype(np.float32)


def compute_descriptor(xyz, config=None, seed=0):
    config = config or GeometryConfig()
    xyz = np.asarray(xyz, dtype=np.float64)
    if xyz.ndim != 2 or xyz.shape[1] != 3 or len(xyz) < 3 or not np.isfinite(xyz).all():
        raise ValueError('Expected at least three finite XYZ points')
    rng = np.random.RandomState(seed)
    if len(xyz) > config.max_points:
        xyz = xyz[rng.choice(len(xyz), config.max_points, replace=False)]
    xyz = local_frame(xyz)
    xyz /= max(np.linalg.norm(np.ptp(xyz, axis=0)), 1e-8)
    extent = np.ptp(xyz, axis=0)
    r1 = extent[2] / np.sqrt(extent[0]**2 + extent[1]**2 + 1e-8)
    eig = np.linalg.eigvalsh(np.cov(xyz[:, :2], rowvar=False))
    r2 = eig[-1] / (eig[0] + 1e-8)
    ns = estimate_normals(xyz, config.small_k).astype(np.float64)
    nl = estimate_normals(xyz, config.large_k).astype(np.float64)
    nl *= np.where((ns * nl).sum(-1) < 0, -1., 1.)[:, None]
    r3 = np.linalg.norm(nl - ns, axis=-1).mean()

    remaining = np.arange(len(xyz))
    planes, inliers = [], np.zeros(len(xyz), dtype=bool)
    for _ in range(config.max_planes):
        if len(remaining) < 10:
            break
        best = np.empty(0, dtype=np.int64)
        for _ in range(config.ransac_trials):
            a, b, c = xyz[rng.choice(remaining, 3, replace=False)]
            n = np.cross(b-a, c-a)
            if np.linalg.norm(n) < 1e-10:
                continue
            n /= np.linalg.norm(n)
            inds = remaining[np.abs((xyz[remaining] - a) @ n) < config.plane_threshold]
            if len(inds) > len(best):
                best = inds
        if len(best) < 10:
            break
        pts = xyz[best]
        _, _, vh = np.linalg.svd(pts - pts.mean(0), full_matrices=False)
        normal = vh[-1]
        planes.append(np.r_[normal, -pts.mean(0) @ normal])
        inliers[best] = True
        remaining = remaining[~np.isin(remaining, best)]
    if planes:
        planes = np.stack(planes)
        distances = np.abs(xyz[inliers] @ planes[:, :3].T + planes[:, 3])
        r4 = distances.min(1).mean()
    else:
        r4 = 0.0
    idx = cKDTree(xyz).query(xyz, k=min(config.small_k, len(xyz)))[1]
    similarity = np.abs((ns[:, None] * ns[idx]).sum(-1))
    edge_ratio = (similarity.mean(1) < np.cos(np.deg2rad(config.edge_angle_degrees))).mean()
    # Explicit proxy for undefined rho_cav: locally concave points, normals outward.
    signed_offset = ((xyz[idx].mean(1) - xyz) * ns).sum(-1)
    cavity_ratio = (signed_offset > config.cavity_threshold).mean()
    return np.array([r1, r2, r3, r4, cavity_ratio + config.cavity_edge_weight * edge_ratio], np.float32)


class FoldGeometricPrior:
    """Fit ONLY on source scenes; all five types must be represented."""
    def __init__(self, temperature=1.0, deviation_temperature=1.0, std_floor=1e-4):
        if min(temperature, deviation_temperature, std_floor) <= 0:
            raise ValueError('Prior temperatures and std_floor must be positive')
        self.temperature, self.deviation_temperature, self.std_floor = temperature, deviation_temperature, std_floor

    def fit(self, descriptors, cave_types, source_ids, target_id):
        if target_id in source_ids:
            raise ValueError('Target scene cannot be included in prior statistics')
        descriptors = np.asarray(descriptors, dtype=np.float64)
        types = np.asarray(cave_types)
        self.mean, self.std = [], []
        for k in range(5):
            group = descriptors[types == k]
            if len(group) == 0:
                raise ValueError('No source scene for cave type ' + CAVE_TYPES[k])
            self.mean.append(group.mean(0))
            self.std.append(np.maximum(group.std(0), self.std_floor))
        self.mean, self.std = np.stack(self.mean), np.stack(self.std)
        self.source_ids = list(source_ids)
        return self

    def predict(self, descriptor):
        distance = (((np.asarray(descriptor) - self.mean) / self.std)**2).sum(-1)
        logits = -distance / self.temperature
        prob = np.exp(logits - logits.max())
        prob /= prob.sum()
        deviation = 1 - np.exp(-distance.min() / self.deviation_temperature)
        return prob.astype(np.float32), np.float32(deviation)
