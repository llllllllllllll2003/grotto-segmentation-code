"""Routing, teacher filtering and prototype transport (paper Eqs. 6-29)."""
import math
import torch
from torch import nn
import torch.nn.functional as F
from learnable_typology import SimpleGeometryEncoder


class CavePrototypeRouter(nn.Module):
    def __init__(self, feat_dim, slots=8, embed_dim=128, temperature=0.5,
                 gumbel_temperature=0.5, prior_weight=1.0, deviation_weight=1.0):
        super().__init__()
        if slots != 8:
            raise ValueError('Paper configuration requires five anchored + three adaptive slots')
        self.encoder = SimpleGeometryEncoder(feat_dim, embed_dim)
        self.prototypes = nn.Parameter(F.normalize(torch.randn(slots, embed_dim), dim=-1))
        self.adaptive_bias = nn.Parameter(torch.zeros(slots - 5))
        self.temperature, self.gumbel_temperature = temperature, gumbel_temperature
        self.prior_weight, self.deviation_weight = prior_weight, deviation_weight

    def forward(self, feat, xyz, seg_logits, prior, deviation):
        # Float32 routing avoids small prior probabilities underflowing in AMP.
        with torch.autocast(device_type=feat.device.type, enabled=False):
            embed = self.encoder(feat.float(), xyz.float(), seg_logits.float())
            scores = F.normalize(embed, dim=-1) @ F.normalize(self.prototypes.float(), dim=-1).T
            scores = scores / self.temperature
            scores = torch.cat((scores[:, :5] + self.prior_weight * prior.float().clamp_min(1e-8).log(),
                                scores[:, 5:] + self.adaptive_bias + self.deviation_weight * deviation[:, None]), -1)
            deterministic = scores.softmax(-1)
            assignments = F.gumbel_softmax(scores, tau=self.gumbel_temperature, hard=False) if self.training else deterministic
            context = assignments @ self.prototypes
        return dict(assignments=assignments, deterministic=deterministic,
                    anchor_deterministic=scores[:, :5].softmax(-1), context=context,
                    type_id=deterministic.argmax(-1), embedding=embed)

    @staticmethod
    def constraint_loss(route, cave_types, is_source, prior, smoothing=0.1,
                        adaptive_limit=0.1, sparse_weight=1.0, geo_weight=1.0):
        zero = route['context'].sum() * 0
        anchor = sparse = geo = zero
        src = is_source.bool()
        if src.any():
            types = cave_types[src]
            if ((types < 0) | (types > 4)).any():
                raise ValueError('Source cave types must be in [0,4]')
            soft_label = (1-smoothing)*F.one_hot(types, 5) + smoothing*prior[src]
            a = route['assignments'][src, :5]
            a = a / a.sum(-1, keepdim=True).clamp_min(1e-8)
            anchor = -(soft_label * a.clamp_min(1e-8).log()).sum(-1).mean()
            sparse = F.relu(route['assignments'][src, 5:].sum(-1)-adaptive_limit).mean()
        if (~src).any():
            s = prior[~src].float()
            a = route['anchor_deterministic'][~src]
            kl = (s * (s.clamp_min(1e-8).log() - a.clamp_min(1e-8).log())).sum(-1)
            geo = (s.max(-1).values * kl).mean()
        return anchor + sparse_weight*sparse + geo_weight*geo


def complementary_channel_masks(channels, keep_rate=0.625, shared_rate=0.25, device='cpu'):
    """Fixed cardinality shared channels + two disjoint private channel sets."""
    keep, shared = round(channels*keep_rate), round(channels*shared_rate)
    if not (0 <= shared <= keep <= channels and 2*keep-shared <= channels and keep > 0):
        raise ValueError('Infeasible channel retention/shared rates')
    order = torch.randperm(channels, device=device)
    m1, m2 = torch.zeros(channels, device=device), torch.zeros(channels, device=device)
    m1[order[:keep]] = 1
    m2[order[:shared]] = 1
    m2[order[keep:2*keep-shared]] = 1
    return m1*(channels/keep), m2*(channels/keep)


class ClassAdaptiveThreshold(nn.Module):
    def __init__(self, momentum=0.999, floors=(0.85, 0.65), ceiling=0.95):
        super().__init__()
        self.momentum, self.ceiling = momentum, ceiling
        self.register_buffer('floors', torch.tensor(floors))
        self.register_buffer('thresholds', torch.tensor(floors))

    @torch.no_grad()
    def update(self, confidence, prediction, eligible):
        for c in range(len(self.thresholds)):
            selected = eligible & (prediction == c)
            if selected.any():
                self.thresholds[c].mul_(self.momentum).add_(confidence[selected].mean(), alpha=1-self.momentum)
        self.thresholds.copy_(torch.maximum(self.floors, self.thresholds.clamp(max=self.ceiling)))

    def consensus(self, out1, out2, labels, is_source, filtering=True):
        prob1, prob2 = out1['seg'].float().softmax(-1), out2['seg'].float().softmax(-1)
        conf1, cls1 = prob1.max(-1)
        conf2, cls2 = prob2.max(-1)
        eligible = (~is_source.bool())[:, None] & (labels == 255)
        agreed = (cls1 == cls2) & (out1['routing']['type_id'] == out2['routing']['type_id'])[:, None]
        self.update(torch.cat([conf1, conf2]), torch.cat([cls1, cls2]), torch.cat([eligible, eligible]))
        mask = eligible & agreed
        if filtering:
            threshold = self.thresholds[cls1]
            mask &= (conf1 > threshold) & (conf2 > threshold)
        return cls1, mask, ((prob1+prob2)*0.5).detach(), torch.minimum(conf1, conf2)


def pseudo_losses(logits, pseudo, mask, soft_teacher, gamma=1.5):
    if not mask.any():
        zero = logits.sum()*0
        return zero, zero
    logp = logits[mask].float().log_softmax(-1)
    chosen = logp.gather(-1, pseudo[mask].unsqueeze(-1)).squeeze(-1)
    focal = (-((1-chosen.exp())**gamma)*chosen).mean()
    consistency = F.kl_div(logp, soft_teacher[mask].float(), reduction='none').sum(-1).mean()
    return focal, consistency


@torch.no_grad()
def _balance(kernel, rows, cols, iterations=80):
    # Diagonal scaling preserves nonnegativity and the factor rank bound.
    kernel = kernel.clamp_min(1e-30)
    v = torch.ones_like(cols)
    for _ in range(iterations):
        u = rows / (kernel @ v).clamp_min(1e-30)
        v = cols / (kernel.T @ u).clamp_min(1e-30)
    return u[:, None]*kernel*v[None, :]


@torch.no_grad()
def low_rank_transport(cost, rank=3, iterations=40, reg=0.05):
    """Feasible nonnegative factorisation T=Q diag(1/g) R^T, rank(T)<=r.

    Mirror-descent approximation to Eq. (27), not a global optimality claim.
    Both factors have fixed column mass g; final scaling enforces both marginals.
    Unlike truncation/clamping an SVD, nonnegative factors retain the rank bound.
    """
    if cost.ndim != 2 or min(cost.shape) == 0 or rank < 1 or reg <= 0:
        raise ValueError('Invalid transport dimensions, rank or regularization')
    dtype = cost.dtype
    cost = cost.detach().double()
    m, n = cost.shape
    r = min(rank, m, n)
    mu, nu = cost.new_full((m,), 1/m), cost.new_full((n,), 1/n)
    g = cost.new_full((r,), 1/r)
    q = _balance(torch.exp(torch.cos(torch.arange(m*r, device=cost.device).reshape(m,r).double())), mu, g)
    v = _balance(torch.exp(torch.sin(torch.arange(n*r, device=cost.device).reshape(n,r).double())), nu, g)
    for _ in range(iterations):
        dq = cost @ (v/g)
        dv = cost.T @ (q/g)
        # Entropic smoothing and conservative mirror-descent step.
        lq = q.clamp_min(1e-30).log() - 0.25*(dq + reg*q.clamp_min(1e-30).log())
        lv = v.clamp_min(1e-30).log() - 0.25*(dv + reg*v.clamp_min(1e-30).log())
        q = _balance((lq-lq.max()).exp(), mu, g)
        v = _balance((lv-lv.max()).exp(), nu, g)
    plan = _balance((q/g) @ v.T, mu, nu, iterations=200)
    return plan.to(dtype)


class DomainPrototypeBank(nn.Module):
    """Separate domain/slot/class cells. Current batch centres retain gradients."""
    def __init__(self, feat_dim, slots=8, classes=2, min_points=10, confidence_threshold=0.65,
                 momentum_start=0.9, momentum_end=0.999, warmup_epochs=10,
                 decay=0.001, min_trusted=4, temperature=0.07, rank=3):
        super().__init__()
        self.K, self.C = slots, classes
        self.min_points, self.confidence_threshold = min_points, confidence_threshold
        self.momentum_start, self.momentum_end, self.warmup_epochs = momentum_start, momentum_end, warmup_epochs
        self.decay, self.min_trusted, self.temperature, self.rank = decay, min_trusted, temperature, rank
        self.register_buffer('prototypes', torch.zeros(2, slots, classes, feat_dim))
        self.register_buffer('trusted', torch.zeros(2, slots, classes, dtype=torch.bool))
        self.register_buffer('last_update', torch.zeros(2, slots, classes, dtype=torch.long))
        self.register_buffer('step', torch.tensor(0, dtype=torch.long))

    def forward(self, feat, assignment, labels, valid, is_source, confidence, epoch=0):
        b, n, dim = feat.shape
        f = feat.float().reshape(-1, dim)
        a = assignment.float()[:, None].expand(-1, n, -1).reshape(-1, self.K)
        cls, mask, conf = labels.reshape(-1), valid.reshape(-1), confidence.reshape(-1).float()
        domains = (~is_source.bool())[:, None].expand(-1, n).reshape(-1).long()
        centers, accepted = {}, torch.zeros_like(self.trusted)
        for domain in range(2):
            for c in range(self.C):
                eligible = mask & (domains == domain) & (cls == c)
                if int(eligible.sum()) < self.min_points:
                    continue
                for k in range(self.K):
                    weights = a[eligible, k]*conf[eligible]
                    # Soft routing gives each valid point a fractional contribution.
                    # Reject numerically zero-mass cells; cardinality and confidence
                    # are tested independently, as in Eq. (25).
                    mean_conf = (a[eligible,k]*conf[eligible]).sum()/a[eligible,k].sum().clamp_min(1e-8)
                    if weights.sum().detach() <= 1e-6 or mean_conf.detach() < self.confidence_threshold:
                        continue
                    centers[domain,k,c] = (f[eligible]*weights[:,None]).sum(0)/weights.sum().clamp_min(1e-8)
                    accepted[domain,k,c] = True
        # Clone first: autograd must not reference buffers modified by EMA below.
        live = self.prototypes.detach().clone()
        live_trusted = self.trusted.clone() | accepted
        for key, center in centers.items():
            live[key] = center
        zero = feat.sum()*0
        align = proto = zero
        ready = all(int(live_trusted[d].sum()) >= self.min_trusted for d in range(2))
        if ready:
            costs = []
            for c in range(self.C):
                sm, tm = live_trusted[0,:,c], live_trusted[1,:,c]
                if sm.any() and tm.any():
                    cost = 1-F.normalize(live[0,sm,c],dim=-1) @ F.normalize(live[1,tm,c],dim=-1).T
                    plan = low_rank_transport(cost, self.rank)
                    costs.append((plan*cost).sum())
            if costs:
                align = sum(costs)/self.C
            # Query points use their own domain bank; same-class soft assignment
            # forms q_ij, with unavailable slots masked from the denominator.
            terms, counts = [], []
            for domain in range(2):
                active = live_trusted[domain].reshape(-1)
                queries = mask & (domains == domain)
                if not queries.any() or not active.any():
                    continue
                reference = F.normalize(live[domain].detach().reshape(-1, dim)[active],dim=-1)
                scores = F.normalize(f[queries],dim=-1) @ reference.T / self.temperature
                target = (a[queries,:,None]*F.one_hot(cls[queries],self.C)[:,None,:]).reshape(-1,self.K*self.C)[:,active]
                mass = target.sum(-1)
                use = mass > 1e-8
                if use.any():
                    target = target[use]/mass[use,None]
                    terms.append(-(target*scores[use].log_softmax(-1)).sum())
                    counts.append(int(use.sum()))
            if terms:
                proto = sum(terms)/sum(counts)
        momentum = self.momentum_start + (self.momentum_end-self.momentum_start)*min(1.,epoch/max(1,self.warmup_epochs))
        with torch.no_grad():
            self.step.add_(1)
            for key in [(d,k,c) for d in range(2) for k in range(self.K) for c in range(self.C)]:
                if key in centers:
                    center = centers[key].detach()
                    if self.trusted[key]:
                        self.prototypes[key].mul_(momentum).add_(center,alpha=1-momentum)
                    else:
                        self.prototypes[key].copy_(center)
                    self.trusted[key] = True
                    self.last_update[key] = self.step
                else:
                    age = int(self.step-self.last_update[key])
                    self.prototypes[key].mul_(math.exp(-self.decay*age))
        return align, proto
