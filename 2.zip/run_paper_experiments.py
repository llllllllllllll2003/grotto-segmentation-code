"""Run paper Table 8 ablations and LOSO folds. See README_论文对齐.md."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
from cave_priors import GeometryConfig
from paper_data import load_manifest, load_scene, prepare_fold
from core_engine_paper import PaperConfig, train_fold


def experiment_config(method,epochs=100,points=40960,steps=500,workers=0):
    if method not in ('A1','A2','A3','A4','A5'):
        raise ValueError('Unknown paper ablation: '+method)
    config = PaperConfig(name=method,epochs=epochs,num_points=points,steps_per_epoch=steps,workers=workers)
    config.use_cave_router = method != 'A1'
    config.use_teachers = method in ('A3','A4','A5')
    config.use_filtering = method in ('A4','A5')
    config.use_alignment = method == 'A5'
    return config


def main(argv=None):
    parser = argparse.ArgumentParser(description='Paper-aligned cave-type segmentation, 17-fold LOSO')
    parser.add_argument('--manifest',default=str(Path(__file__).with_name('scenes.example.json')))
    parser.add_argument('--mode',choices=['full','ablation'],default='full')
    parser.add_argument('--methods',nargs='+',choices=['A1','A2','A3','A4','A5'])
    parser.add_argument('--folds',nargs='+',help='Target scene IDs, e.g. S1 S2 (default: every scene)')
    parser.add_argument('--seeds',nargs='+',type=int,default=[42])
    parser.add_argument('--sampling-seed',type=int,default=0,help='Fixed sparse-label subset across methods/seeds')
    parser.add_argument('--sparse-ratio',type=float,default=0.01)
    parser.add_argument('--epochs',type=int,default=100)
    parser.add_argument('--points',type=int,default=40960)
    parser.add_argument('--steps',type=int,default=500)
    parser.add_argument('--workers',type=int,default=0)
    parser.add_argument('--output',default='results_paper')
    parser.add_argument('--check-data',action='store_true',help='Validate and prepare folds without training')
    parser.add_argument('--show-config',action='store_true',help='Print loss/optimizer/ablation settings, no data needed')
    parser.add_argument('--allow-other-scene-count',action='store_true',help='Debug only; not the 17-scene paper protocol')
    args = parser.parse_args(argv)
    methods = args.methods or (['A5'] if args.mode == 'full' else ['A1','A2','A3','A4','A5'])
    if not (0 < args.sparse_ratio < 1):
        parser.error('sparse-ratio must be between 0 and 1 for held-out evaluation')
    if args.show_config:
        print(json.dumps({m:asdict(experiment_config(m,args.epochs,args.points,args.steps,args.workers)) for m in methods},indent=2))
        return
    manifest = load_manifest(args.manifest,require_17=not args.allow_other_scene_count)
    ids = [s['id'] for s in manifest['scenes']]
    folds = args.folds or ids
    if set(folds)-set(ids):
        parser.error('Unknown target scene IDs: '+str(set(folds)-set(ids)))
    geometry = GeometryConfig(**manifest.get('geometry',{}))
    print('Loading scenes and geometry (only source scenes fit fold statistics)...',flush=True)
    scenes = [load_scene(s,geometry) for s in manifest['scenes']]
    output = Path(args.output)
    output.mkdir(parents=True,exist_ok=True)
    records = []
    for target in folds:
        train,evaluation,sparse,prior = prepare_fold(scenes,target,args.sparse_ratio,args.sampling_seed,
                                                    manifest.get('prior',{}))
        print(f'{target}: source={len(train)-1} labeled_target={len(sparse)} eval_points={(evaluation["labels"]!=255).sum()}',flush=True)
        # Persist source-only prior statistics and exact target annotation indices.
        fold_dir = output/target
        fold_dir.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(fold_dir/'fold_setup.npz',mean=prior.mean,std=prior.std,
                            source_ids=np.asarray(prior.source_ids),sparse_indices=sparse,
                            sampling_seed=args.sampling_seed,sparse_ratio=args.sparse_ratio)
        if args.check_data:
            continue
        for method in methods:
            for seed in args.seeds:
                config = experiment_config(method,args.epochs,args.points,args.steps,args.workers)
                result = train_fold(config,train,evaluation,seed,output,prior,sparse)
                records.append(dict(fold=target,method=method,seed=seed,**result))
                (output/'results.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    if records:
        # First average seeds within each fold, then give every scene equal weight.
        summary = {}
        for method in methods:
            by_fold = []
            for fold in folds:
                rows = [r for r in records if r['method']==method and r['fold']==fold]
                by_fold.append({k:float(np.mean([r[k] for r in rows])) for k in ('oa','macc','miou','iou_fg')})
            summary[method] = {k:float(np.mean([r[k] for r in by_fold])) for k in ('oa','macc','miou','iou_fg')}
        (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
