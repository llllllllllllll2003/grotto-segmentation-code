"""Compatibility filename for the revised paper implementation.

The old ExperimentConfigV12/train_one_run_v12 interface is intentionally retired:
its split/checkpoint-selection protocol differs from the paper. The exact original
is preserved in originals/core_engine_v15_ptv3.py.
"""
from core_engine_paper import PaperConfig, train_fold, evaluate, compute_training_loss

__all__ = ['PaperConfig', 'train_fold', 'evaluate', 'compute_training_loss']
