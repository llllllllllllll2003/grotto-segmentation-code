"""
learnable_typology.py 

class SinusoidalPositionEncoding(nn.Module):

    def __init__(self, d_model=32, max_freq_log2=6):
        super().__init__()
        n_freq = max(1, d_model // 6)
        freqs = 2.0 ** torch.linspace(0, max_freq_log2, n_freq)
        self.register_buffer('freqs', freqs)
        self.out_dim = n_freq * 6

    def forward(self, xyz):
        scaled = xyz.unsqueeze(-1) * self.freqs.view(1, 1, 1, -1)
        pe = torch.cat([torch.sin(scaled), torch.cos(scaled)], dim=-1)
        return pe.reshape(xyz.shape[0], xyz.shape[1], -1)


class SpatialPartitionPooling(nn.Module):
       def __init__(self, divisions=2):
        super().__init__()
        self.div = divisions
        self.num_regions = divisions ** 3

    def forward(self, xyz, feat):
        B, N, D = feat.shape
        R = self.num_regions
        device = feat.device

        xyz_min = xyz.min(dim=1, keepdim=True).values
        xyz_max = xyz.max(dim=1, keepdim=True).values
        xyz_norm = (xyz - xyz_min) / (xyz_max - xyz_min + 1e-8)
        grid = (xyz_norm * self.div).long().clamp(0, self.div - 1)
        region_id = (grid[..., 2] * self.div * self.div
                     + grid[..., 1] * self.div + grid[..., 0])

        batch_offset = torch.arange(B, device=device).unsqueeze(1) * R
        flat_idx = (batch_offset + region_id).reshape(-1)
        flat_feat = feat.reshape(-1, D)
        total_bins = B * R

        ones = torch.ones(B * N, 1, device=device)
        count = torch.zeros(total_bins, 1, device=device)
        count.scatter_add_(0, flat_idx.unsqueeze(1), ones)
        feat_sum = torch.zeros(total_bins, D, device=device)
        feat_sum.scatter_add_(0, flat_idx.unsqueeze(1).expand(-1, D), flat_feat)
        region_mean = feat_sum / count.clamp(min=1)

        region_max = torch.full((total_bins, D), -1e9, device=device)
        region_max.scatter_reduce_(
            0, flat_idx.unsqueeze(1).expand(-1, D), flat_feat,
            reduce='amax', include_self=False)
        empty = (count.squeeze(-1) == 0)
        region_max = torch.where(empty.unsqueeze(-1),
                                 torch.zeros_like(region_max), region_max)

        region_mask = (count.squeeze(-1) > 0).reshape(B, R)
        region_feats = torch.cat([
            region_max.reshape(B, R, D),
            region_mean.reshape(B, R, D)
        ], dim=-1)
        return region_feats, region_mask

class SimpleGeometryEncoder(nn.Module):
      def __init__(self, feat_dim, embed_dim=128, pe_dim=32, divisions=2):
        super().__init__()
        self.pe = SinusoidalPositionEncoding(d_model=pe_dim)
        self.feat_proj = nn.Linear(feat_dim + self.pe.out_dim, feat_dim)
        self.spatial_pool = SpatialPartitionPooling(divisions)
        self.embed_dim = embed_dim

        region_dim = feat_dim * 2  # max + mean

        self.region_proj = nn.Sequential(
            nn.Linear(region_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
        )

        self.fg_proj = nn.Sequential(
            nn.Linear(feat_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
        )

        self.fuse = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.GELU(),
            nn.Linear(embed_dim, embed_dim),
        )

    def forward(self, point_feat, xyz=None, seg_logits=None):
        B, N, D = point_feat.shape


        if xyz is not None:
            feat_aug = self.feat_proj(
                torch.cat([point_feat, self.pe(xyz)], dim=-1))
        else:
            feat_aug = point_feat


        if xyz is not None:
            region_feats, region_mask = self.spatial_pool(xyz, feat_aug)
        else:
            region_feats, region_mask = self.spatial_pool(
                feat_aug[..., :3], feat_aug)

       
        region_emb = self.region_proj(region_feats)  # (B, R, E)

        mask_f = region_mask.float().unsqueeze(-1)  # (B, R, 1)
        region_agg = (region_emb * mask_f).sum(1) / mask_f.sum(1).clamp(min=1)  # (B, E)


        if seg_logits is not None:
            fg_w = torch.softmax(seg_logits, -1)[..., 1:2]
            fg_pool = (feat_aug * fg_w).sum(1) / fg_w.sum(1).clamp(min=1e-6)
        else:
            fg_pool = feat_aug.mean(dim=1)
        fg_emb = self.fg_proj(fg_pool)  # (B, E)

        # 融合
        return self.fuse(torch.cat([region_agg, fg_emb], dim=-1))  # (B, E)



class LinearTemperatureScheduler:
      def __init__(self, tau_max=1.0, tau_min=0.4, tau_floor=0.4):
        self.tau_max = tau_max
        self.tau_min = max(tau_min, tau_floor)
        self.tau_floor = tau_floor
        self.tau_current = tau_max

    def step(self, epoch, total_epochs, div_loss_val=None):
        progress = min(1.0, epoch / max(1, total_epochs - 1))
        self.tau_current = max(
            self.tau_floor,
            self.tau_max - (self.tau_max - self.tau_min) * progress
        )
        return self.tau_current

    def get_current(self):
        return self.tau_current

class LearnableTypologyModule(nn.Module):
      def __init__(self, feat_dim, num_typologies=8, embed_dim=128,
                 gumbel_hard=False, pe_dim=32, spatial_div=2):
        super().__init__()
        self.K = num_typologies
        self.geo_encoder = SimpleGeometryEncoder(
            feat_dim, embed_dim, pe_dim, spatial_div)
        self.typo_prototypes = nn.Parameter(
            F.normalize(torch.randn(num_typologies, embed_dim), p=2, dim=-1))
        self.proj_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim), nn.GELU(),
            nn.Linear(embed_dim, embed_dim))
        self.gt_align_head = nn.Linear(embed_dim, num_typologies)
        self.gumbel_hard = gumbel_hard

        self.register_buffer('global_usage',
                             torch.ones(num_typologies) / num_typologies)

    def forward(self, point_feat, seg_logits=None, xyz=None, temperature=0.5):
        tau = max(temperature, 0.4)
        scene_embed = self.geo_encoder(point_feat, xyz=xyz, seg_logits=seg_logits)
        z = F.normalize(self.proj_head(scene_embed), p=2, dim=-1)

        if self.training:
            with torch.no_grad():
                raw_logits = torch.matmul(
                    z, F.normalize(self.typo_prototypes, p=2, dim=-1).T)
                batch_usage = torch.softmax(raw_logits / tau, dim=-1).mean(0)
                self.global_usage = 0.9 * self.global_usage + 0.1 * batch_usage

                # VQ-VAE 风格死区重置
                dead_mask = self.global_usage < (1.0 / (self.K * 5))
                if dead_mask.any():
                    num_dead = dead_mask.sum().item()
                    random_feats = F.normalize(
                        torch.randn(num_dead, self.typo_prototypes.shape[-1],
                                    device=z.device), p=2, dim=-1)
                    self.typo_prototypes.data[dead_mask] = random_feats
                    self.global_usage[dead_mask] = 1.0 / self.K

        protos = F.normalize(self.typo_prototypes, p=2, dim=-1)
        logits = torch.matmul(z, protos.T) / tau

        if self.training:
            typo_soft = F.gumbel_softmax(logits, tau=tau, hard=self.gumbel_hard)
        else:
            typo_soft = torch.softmax(logits, dim=-1)

        return typo_soft, logits.argmax(-1), scene_embed

    def compute_entropy_loss(self, typo_soft):

        return -(typo_soft * torch.log(typo_soft + 1e-8)).sum(-1).mean()

    def compute_diversity_loss(self, typo_soft):

        avg_prob = typo_soft.mean(0)
        return (avg_prob * torch.log(avg_prob + 1e-8)).sum()

    def compute_gt_alignment_loss(self, scene_embed, gt_labels):
        valid = gt_labels >= 0
        if valid.sum() == 0:
            return scene_embed.sum() * 0.0
        return F.cross_entropy(self.gt_align_head(scene_embed[valid]),
                               gt_labels[valid])

    def get_prototype_min_angle(self):
        with torch.no_grad():
            protos = F.normalize(self.typo_prototypes, p=2, dim=-1)
            sim = torch.matmul(protos, protos.T)
            mask = ~torch.eye(self.K, dtype=torch.bool, device=sim.device)
            max_cos = sim[mask].max().item()
            return math.degrees(math.acos(min(1.0, max(max_cos, -1.0))))

class SoftTypologyMemoryBank(nn.Module):

    def __init__(self, feat_dim, num_typologies=8, num_classes=2,
                 momentum_final=0.999, temperature=0.07,
                 min_updates=10, warmup_epochs=10):
        super().__init__()
        self.K, self.nc, self.tau = num_typologies, num_classes, temperature
        self.momentum_final = momentum_final
        self.min_updates, self.warmup_epochs = min_updates, warmup_epochs
        self.register_buffer("prototypes",
            F.normalize(torch.randn(num_typologies, num_classes, feat_dim),
                        p=2, dim=-1))
        self.register_buffer("update_count",
                             torch.zeros(num_typologies, num_classes))
        self.register_buffer("trusted",
            torch.zeros(num_typologies, num_classes, dtype=torch.bool))
        self._epoch = 0

    def set_epoch(self, epoch):
        self._epoch = epoch
        self.trusted = self.update_count >= self.min_updates

    def _momentum(self, k, c):
        ep_p = min(1.0, self._epoch / max(1, self.warmup_epochs))
        m_base = 0.9 + ep_p * (self.momentum_final - 0.9)
        m_cnt = min(self.momentum_final,
                    1.0 - 1.0 / (self.update_count[k, c].item() + 1))
        return max(m_base, m_cnt)

    def update(self, feat, typo_soft, seg_lbl, mask, confidence=None):
        with torch.no_grad():
            for c in range(self.nc):
                cm = (seg_lbl == c) & mask
                if cm.sum() == 0:
                    continue
                fc = F.normalize(feat[cm], p=2, dim=-1)
                tc = typo_soft[cm]
                w_conf = (confidence[cm] if confidence is not None
                          else torch.ones(fc.shape[0], device=fc.device))
                for k in range(self.K):
                    wk = tc[:, k] * w_conf
                    if wk.sum() < 1e-6:
                        continue
                    mu = F.normalize(
                        (fc * wk.unsqueeze(-1)).sum(0) / (wk.sum() + 1e-8),
                        p=2, dim=-1)
                    m = self._momentum(k, c)
                    self.prototypes[k, c] = F.normalize(
                        m * self.prototypes[k, c] + (1 - m) * mu, p=2, dim=-1)
                    self.update_count[k, c] += 1

    def loss(self, feat, typo_soft, seg_lbl, mask):
        if mask.sum() == 0:
            return feat.sum() * 0.0
        f = F.normalize(feat[mask], p=2, dim=-1)
        a, c = typo_soft[mask], seg_lbl[mask]
        sim = torch.clamp(
            torch.matmul(f, self.prototypes.view(-1, f.shape[-1]).T) / self.tau,
            -50, 50)
        n = f.shape[0]
        td = torch.zeros(n, self.K * self.nc, device=f.device)
        for ci in range(self.nc):
            m = (c == ci)
            if m.sum() == 0:
                continue
            for k in range(self.K):
                if self.trusted[k, ci]:
                    td[m, k * self.nc + ci] = a[m, k]
        valid = (td.sum(-1) > 1e-8)
        if valid.sum() == 0:
            return feat.sum() * 0.0
        td_v = td[valid]
        td_v = td_v / (td_v.sum(-1, keepdim=True) + 1e-8)
        return -(td_v * F.log_softmax(sim[valid], -1)).sum(-1).mean()

    def loss_hard(self, feat, typo_id, seg_lbl, mask):
        if mask.sum() == 0:
            return feat.sum() * 0.0
        f = F.normalize(feat[mask], p=2, dim=-1)
        logits = torch.clamp(
            torch.matmul(f, self.prototypes.view(-1, f.shape[-1]).T) / self.tau,
            -50, 50)
        return F.cross_entropy(logits,
                               typo_id[mask] * self.nc + seg_lbl[mask])

class DynamicCoherenceTracker:
    def __init__(self, K, num_classes=2, alpha=0.01, thresh=0.60, device='cpu'):
        self.K, self.nc = K, num_classes
        self.alpha, self.thresh = alpha, thresh
        self.ema = torch.full((K, num_classes), 0.5,
                              dtype=torch.float32, device=device)

    def update(self, agree_seg, typo_id, pred_cls):
        with torch.no_grad():
            af = agree_seg.float()
            for k in range(self.K):
                for c in range(self.nc):
                    m = (typo_id == k) & (pred_cls == c)
                    if m.sum() > 0:
                        self.ema[k, c] = ((1 - self.alpha) * self.ema[k, c]
                                          + self.alpha * af[m].mean())

    def get_mask(self):
        return self.ema > self.thresh

    def to(self, device):
        self.ema = self.ema.to(device)
        return self
def expand_typo_to_points(typo_soft, typo_id, num_points):
    B, K = typo_soft.shape
    return (typo_soft.unsqueeze(1).expand(B, num_points, K).reshape(-1, K),
            typo_id.unsqueeze(1).expand(B, num_points).reshape(-1))


AdaptiveTemperatureScheduler = LinearTemperatureScheduler

class TypologyVisualizer:
   
    def __init__(self, *args, **kwargs):
        pass

    def collect(self, *args, **kwargs):
        return {}
